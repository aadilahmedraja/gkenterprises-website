window.addEventListener('load', () => {
    setTimeout(() => document.getElementById('preloader').classList.add('done'), 500);
  });

  const header = document.getElementById('siteHeader');
  window.addEventListener('scroll', () => { header.classList.toggle('scrolled', window.scrollY > 40); });

  const menuToggle = document.getElementById('menuToggle');
  const navLinks = document.getElementById('navLinks');
  menuToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Cursor glow
  if (!reduceMotion && window.matchMedia('(pointer: fine)').matches) {
    const glow = document.getElementById('cursorGlow');
    window.addEventListener('mousemove', (e) => {
      glow.classList.add('active');
      glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%,-50%)`;
    });
    window.addEventListener('mouseleave', () => glow.classList.remove('active'));
  }

  // Scroll reveal
  const revealEls = document.querySelectorAll('.reveal, .reveal-stagger');
  if (reduceMotion) {
    revealEls.forEach(el => el.classList.add('in'));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { entry.target.classList.add('in'); io.unobserve(entry.target); }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  }

  document.querySelectorAll('.reveal-stagger').forEach(group => {
    Array.from(group.children).forEach((child, i) => { child.style.transitionDelay = (i * 0.08) + 's'; });
  });

  // Counters
  const counters = document.querySelectorAll('.num[data-count]');
  const countIO = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count, 10);
        const suffix = el.dataset.suffix || '';
        if (reduceMotion) { el.textContent = target + suffix; countIO.unobserve(el); return; }
        let cur = 0;
        const dur = 1200;
        const start = performance.now();
        function tick(now) {
          const p = Math.min((now - start) / dur, 1);
          cur = Math.floor(p * target);
          el.textContent = cur + suffix;
          if (p < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        countIO.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => countIO.observe(c));

  // Architecture progress line
  const archSteps = document.getElementById('archSteps');
  const archFill = document.getElementById('archFill');
  const stepEls = document.querySelectorAll('.arch-step');
  window.addEventListener('scroll', () => {
    const rect = archSteps.getBoundingClientRect();
    const vh = window.innerHeight;
    const total = rect.height;
    const progressed = Math.min(Math.max(vh * 0.6 - rect.top, 0), total);
    const pct = total > 0 ? (progressed / total) * 100 : 0;
    archFill.style.height = pct + '%';
    stepEls.forEach((step) => {
      const sRect = step.getBoundingClientRect();
      step.classList.toggle('active', sRect.top < vh * 0.6);
    });
  });

  function getFormData(){
    return {
      name: document.getElementById('name').value.trim(),
      company: document.getElementById('company').value.trim(),
      email: document.getElementById('email').value.trim(),
      product: document.getElementById('product').value,
      message: document.getElementById('message').value.trim()
    };
  }
  function buildMessage(d){
    return 'New Quote Request\n\n' +
      'Name: ' + d.name + '\n' +
      'Company: ' + (d.company || '-') + '\n' +
      'Email: ' + d.email + '\n' +
      'Product: ' + d.product + '\n' +
      'Details: ' + (d.message || '-');
  }
  const quoteForm = document.getElementById('quoteForm');
  document.getElementById('sendEmailBtn').addEventListener('click', () => {
    if (!quoteForm.reportValidity()) return;
    const d = getFormData();
    const subject = encodeURIComponent('Quote Request - ' + d.product);
    const body = encodeURIComponent(buildMessage(d));
    window.location.href = 'mailto:salesgkenterprises71@gmail.com?subject=' + subject + '&body=' + body;
    document.getElementById('formNote').textContent = 'Opening your email app with this request pre-filled...';
  });
  document.getElementById('sendWhatsAppBtn').addEventListener('click', () => {
    if (!quoteForm.reportValidity()) return;
    const d = getFormData();
    const text = encodeURIComponent(buildMessage(d));
    window.open('https://wa.me/918825401171?text=' + text, '_blank');
    document.getElementById('formNote').textContent = 'Opening WhatsApp with this request pre-filled...';
  });

  // Google Maps: auto-link the address text so updating the address updates the map too
  const mapLink = document.getElementById('mapLink');
  if (mapLink) {
    const addressText = mapLink.textContent.trim().replace(/\s+/g, ' ');
    mapLink.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(addressText);
  }

  // 3D tilt for the flagship product image
  document.querySelectorAll('.tilt-3d').forEach(el => {
    const img = el.querySelector('img');
    el.addEventListener('mousemove', (e) => {
      const rect = el.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      img.style.transform = 'rotateY(' + (x * 26) + 'deg) rotateX(' + (-y * 26) + 'deg) scale(1.08)';
    });
    el.addEventListener('mouseleave', () => { img.style.transform = 'rotateY(0deg) rotateX(0deg) scale(1)'; });
  });